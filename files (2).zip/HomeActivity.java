// App 12 — Scenarios 2, 3, 4
// File: HomeActivity.java (Activity B)

package com.example.intents;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    TextView tvWelcome;
    Button   btnGoogle, btnDial, btnAge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        tvWelcome = findViewById(R.id.tvWelcome);
        btnGoogle = findViewById(R.id.btnGoogle);
        btnDial   = findViewById(R.id.btnDial);
        btnAge    = findViewById(R.id.btnAge);

        // ── SCENARIO 1: Receive username from LoginActivity ──────────
        String username = getIntent().getStringExtra("username");
        tvWelcome.setText("Welcome, " + username + "!");


        // ── SCENARIO 2: Open Google in Browser (Implicit Intent) ─────
        btnGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.google.com"));
                startActivity(intent);
            }
        });


        // ── SCENARIO 3: Pre-filled Dialer (ACTION_DIAL) ──────────────
        btnDial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // ACTION_DIAL opens the dialer with number pre-filled
                // Does NOT call automatically — user presses call
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:+919876543210"));
                startActivity(intent);
            }
        });


        // ── SCENARIO 4: Pass integer (age) to AgeActivity ───────────
        btnAge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, AgeActivity.class);
                intent.putExtra("age", 21);   // passing integer
                startActivity(intent);
            }
        });
    }
}
