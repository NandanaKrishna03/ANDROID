// App 12 — Scenario 4: Receive integer via Intent
// File: AgeActivity.java

package com.example.intents;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AgeActivity extends AppCompatActivity {

    TextView tvAge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_age);

        tvAge = findViewById(R.id.tvAge);

        // ── SCENARIO 4: Receive integer (age) sent via putExtra() ────
        int age = getIntent().getIntExtra("age", 0);

        tvAge.setText("Age received: " + age);
    }
}
